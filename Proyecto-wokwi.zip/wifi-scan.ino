#include <WiFi.h>
#include <HTTPClient.h>

const char* serverName = "https://proyectoiot-ig63.onrender.com/recibir_datos.php";

void setup() {
  Serial.begin(115200);
  WiFi.begin("Wokwi-GUEST", "", 6);
}

void loop() {
  int valorCO2 = analogRead(34);
  int ppm = map(valorCO2, 0, 4095, 0, 1000); // Simulación de ppm
  Serial.println(ppm);

  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(serverName);
    http.addHeader("Content-Type", "application/x-www-form-urlencoded");

    String datos = "ppm=" + String(ppm);
    int respuesta = http.POST(datos);

    Serial.println("Enviado: " + datos);
    http.end();
  }

  delay(5000);
}